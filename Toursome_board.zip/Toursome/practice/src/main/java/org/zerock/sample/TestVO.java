package org.zerock.sample;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class TestVO {

	String name;
	int age;
	
}
